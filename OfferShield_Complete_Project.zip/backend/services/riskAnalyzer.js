/**
 * OfferShield - Risk Analyzer Service
 * Core Rule Engine for Job & Internship Offer Scam Detection
 */

// Free / public email provider domains
const FREE_EMAIL_DOMAINS = /^(gmail|yahoo|outlook|hotmail|rediffmail|proton|protonmail|ymail|zoho|icloud|aol)\.(com|in|me|net|co\.in)$/i;

// Top brands and their official web domains
const OFFICIAL_BRANDS = {
  tcs: ["tcs.com"],
  infosys: ["infosys.com"],
  wipro: ["wipro.com"],
  amazon: ["amazon.com", "amazon.in", "amazon.jobs"],
  deloitte: ["deloitte.com"],
  accenture: ["accenture.com"],
  flipkart: ["flipkart.com"],
  google: ["google.com", "withgoogle.com", "careers.google.com"],
  microsoft: ["microsoft.com", "careers.microsoft.com"],
  meta: ["meta.com", "metacareers.com"],
  apple: ["apple.com"],
  ibm: ["ibm.com"]
};

// Negation patterns: ensure statements like "we never ask for fees" are not flagged
const NEGATION_PATTERN = /\b(never|do not|don['’]t|does not|doesn['’]t|no|not|without|free of|zero)\b/i;

// Detection rules with weights and explanations
const RULES = [
  {
    id: "pay",
    t: "Upfront payment requested",
    w: 45,
    s: 1, // Severe flag
    neg: true,
    why: "Legitimate employers never charge candidates for registration, uniforms, training kits, equipment or security deposits. This is the #1 job scam indicator.",
    re: /\b(registration|security|training|processing|joining|application|verification|kit|admin|activation|uniform|laptop)\s*(fees?|deposit|charges?|amount|cost)\b|\b(pay|deposit|send|transfer)\s*(?:(?:only|just|a|an|the|rs\.?|inr|₹)\s*)*[\d,]+|\brefundable\b|\bfees?\s+dena\b|\bpehle\s+(paise|payment|fees?)|\bjama\s+karo|\bpaise\s+(dena|bhejo)/gi
  },
  {
    id: "guar",
    t: "Guaranteed job or no interview",
    w: 25,
    s: 1,
    why: "Genuine selection processes always involve technical or HR screening. Direct selection with no evaluation is classic scam bait.",
    re: /\bguarantee[sd]?\s+(a\s+)?(job|placement|selection|offer|internship|income)|\b100\s*%\s*(job|placement|selection|guarantee)|\bselection\s+is\s+(100\s*%\s*)?guaranteed|\bno\s+interview|\bwithout\s+(an\s+)?(interview|test|screening)|\bdirect\s+(joining|selection)|\binstant\s+(joining|offer)/gi
  },
  {
    id: "sal",
    t: "Unrealistic pay",
    w: 30,
    s: 1,
    why: "Unusually high compensation for entry-level tasks signals click-farming, money laundering or advance-fee scams.",
    re: /(?:₹|rs\.?|inr)\s*([\d,]+(?:\.\d+)?)\s*(k|lakhs?|lacs?)?\s*(?:\/|per|a|each)?\s*(day|daily|week|weekly|hour|hr|month|monthly)?/gi,
    custom: true
  },
  {
    id: "sens",
    t: "Asks for sensitive information",
    w: 30,
    s: 1,
    neg: true,
    why: "Personal identity documents (Aadhaar, PAN) or banking details (ATM card, OTP, CVV, PIN) should never be shared before receiving a verified offer.",
    re: /\b(aadhaar|aadhar|pan\s*card|bank\s*(account|details|statement)|card\s*number|cvv|otp|upi\s*pin|password|net\s*banking|debit\s*card|atm)\b/gi
  },
  {
    id: "easy",
    t: "Easy-money language",
    w: 12,
    why: "Vague 'earn from home' or 'copy-paste' promises are designed to lure young students into fraudulent multi-level marketing or task scams.",
    re: /\bearn\s+(lakhs?|big|huge|unlimited|daily|weekly|from\s+home)|\beasy\s+(money|income|earning|work)|\bhigh\s+income|\bpassive\s+income|\bghar\s+baithe|\bcopy[- ]?paste|\bliking\s+(videos|posts)|\bno\s+(experience|skills?|qualification)s?\s+(needed|required)|\btyping\s+(job|work|intern)/gi
  },
  {
    id: "urg",
    t: "Pressure and urgency",
    w: 10,
    why: "Scammers create artificial deadlines to induce panic and prevent candidates from conducting due diligence.",
    re: /\burgent(ly)?\b|\bhurry\b|\blimited\s+(seats?|slots?|vacanc\w+|time)|\bapply\s+(now|immediately|today)|\bonly\s+\d+\s+(seats?|slots?)|\blast\s+chance|\bwithin\s+\d+\s*(hours?|hrs?)|\btoday\s+only|\bconfirm\s+(now|today|immediately)/gi
  }
];

// Regex for extracting domains and hostnames
const DOMAIN_REGEX = /(?:[\w.+-]+@|https?:\/\/|www\.)?((?:[a-z0-9-]+\.)+(?:com|in|org|io|co|net|xyz|online|site|top|click|shop|work|info|biz|co\.in))\b/gi;

// Get the registrable root domain (handles .co.in, .gov.in, etc.)
function getRootDomain(domain) {
  if (!domain) return "";
  const parts = domain.toLowerCase().split(".");
  if (parts.length >= 3 && /\.(co|org|ac|gov|net)\.in$/i.test(domain)) {
    return parts.slice(-3).join(".");
  }
  return parts.slice(-2).join(".");
}

// Extract sentence context around match index
function getSentenceAt(text, index) {
  const start = Math.max(
    text.lastIndexOf(".", index),
    text.lastIndexOf("!", index),
    text.lastIndexOf("\n", index)
  );
  let end = text.slice(index).search(/[.!?\n]/);
  end = end < 0 ? text.length : index + end;
  return text.slice(start + 1, end);
}

// Monthly pay multiplier
const PER_MONTH = {
  hour: 160,
  hr: 160,
  day: 26,
  daily: 26,
  week: 4.3,
  weekly: 4.3,
  month: 1,
  monthly: 1
};

// Criteria list used for explanation and API docs
const CRITERIA = [
  { signal: "Upfront payment requested", points: 45, trigger: "Registration fees, training deposits, security charges, refundable kit fees.", why: "Genuine employers never charge job applicants under any pretext." },
  { signal: "Sensitive personal data", points: 30, trigger: "Requests for Aadhaar, PAN card, bank credentials, debit card, CVV or OTP.", why: "High risk of identity theft and unauthorized financial drain." },
  { signal: "Brand impersonation", points: 30, trigger: "Naming a major company (TCS, Infosys, Amazon) but communicating via Gmail or unofficial domains.", why: "Scammers pose as reputed companies to gain trust." },
  { signal: "Unrealistic pay", points: 30, trigger: "Pay exceeding ₹60,000/month or ₹3,000/day for beginner data entry or home tasks.", why: "Unreasonable pay lures unsuspecting job seekers into traps." },
  { signal: "Guaranteed job or no interview", points: 25, trigger: "“Guaranteed selection”, “100% placement”, “no interview”, “direct joining”.", why: "Real hiring always involves objective screening and evaluation." },
  { signal: "Email and website mismatch", points: 20, trigger: "The sender’s email domain does not match the company website domain.", why: "Commonly used in spoofing and impersonation attacks." },
  { signal: "No employer details", points: 18, trigger: "No verified company name, official website or corporate email address provided.", why: "An anonymous or unidentifiable employer cannot be verified." },
  { signal: "Risky-looking domain", points: 15, trigger: "Cheap TLDs such as .xyz, .online, .site, .top, or typo-squatting names.", why: "Fraudulent career pages frequently rely on disposable domains." },
  { signal: "Easy-money language", points: 12, trigger: "“Earn from home”, “easy income”, “copy paste”, “no experience needed”, “ghar baithe”.", why: "Low-effort, high-earning promises signal deceitful schemes." },
  { signal: "Free email or chat-only contact", points: 10, trigger: "Using Gmail, Yahoo, WhatsApp or Telegram as the sole recruiter contact.", why: "Untraceable disposable communication channels." },
  { signal: "Pressure and urgency", points: 10, trigger: "“Apply today”, “limited seats”, “confirm within 2 hours”, “urgent requirement”.", why: "Designed to rush applicants into bypassing basic security checks." },
  { signal: "Reported by other users", points: 50, trigger: "The domain or recruiter has been flagged by multiple OfferShield users.", why: "Direct community intelligence confirming fraudulent activity." }
];

/**
 * Main Analyze Function
 * @param {string} text - The job or internship offer message
 * @param {string} email - Recruiter's email address (optional)
 * @param {string} website - Company website (optional)
 * @param {Set|Array} reported - Set of reported domains
 */
function analyze(text, email = "", website = "", reported = new Set()) {
  const reportedSet = reported instanceof Set ? reported : new Set(reported);
  const flags = [];
  const ranges = [];
  let maxMonthlySalary = 0;

  text = String(text || "");
  email = String(email || "").trim();
  website = String(website || "").trim();

  // 1. Evaluate pattern rules
  for (const rule of RULES) {
    const hits = [];
    for (const match of text.matchAll(rule.re)) {
      // Custom salary check
      if (rule.custom) {
        let val = parseFloat(match[1].replace(/,/g, ""));
        if (isNaN(val)) continue;
        const multiplier = (match[2] || "").toLowerCase();
        if (multiplier === "k") val *= 1000;
        else if (multiplier.startsWith("l")) val *= 100000;

        const unit = (match[3] || "").toLowerCase();
        if (!unit) continue;
        const monthly = val * (PER_MONTH[unit] || 1);
        if (monthly > maxMonthlySalary) maxMonthlySalary = monthly;
        if (monthly < 60000) continue; // Threshold for suspicious intern/beginner pay
      }

      // Check negation context (e.g., "we never charge any fee")
      if (rule.neg && NEGATION_PATTERN.test(getSentenceAt(text, match.index))) {
        continue;
      }

      hits.push(match);
    }

    if (hits.length > 0) {
      hits.forEach(h => ranges.push([h.index, h.index + h[0].length]));
      flags.push({
        id: rule.id,
        t: rule.t,
        w: rule.w,
        s: rule.s || 0,
        why: rule.why,
        q: [...new Set(hits.map(h => h[0].trim()))].slice(0, 3)
      });
    }
  }

  // 2. Sender and domain checks
  const combinedText = `${text} ${email} ${website}`;
  const detectedDomains = new Set();
  const freeEmailProviders = [];

  for (const m of combinedText.matchAll(DOMAIN_REGEX)) {
    const d = m[1].toLowerCase();
    if (FREE_EMAIL_DOMAINS.test(d)) {
      freeEmailProviders.push(d);
    } else {
      detectedDomains.add(getRootDomain(d));
    }
  }

  const hasChatChannel = /\b(whatsapp|telegram)\b|wa\.me|t\.me\//i.test(text);
  if (freeEmailProviders.length > 0 || hasChatChannel) {
    flags.push({
      id: "ct",
      t: "Free email or chat-app contact",
      w: 10,
      why: "Free email addresses (Gmail/Yahoo) and WhatsApp/Telegram-only contact make it easy to pose as a corporate recruiter while remaining anonymous.",
      q: [...new Set([...freeEmailProviders, ...(hasChatChannel ? ["WhatsApp/Telegram"] : [])])]
    });
  }

  // Check reported domains
  const flaggedReported = [...detectedDomains].filter(d => reportedSet.has(d));
  if (flaggedReported.length > 0) {
    flags.push({
      id: "rep",
      t: "Reported as a scam by other users",
      w: 50,
      s: 1,
      why: "This domain has been flagged and reported as fraudulent by multiple OfferShield users.",
      q: flaggedReported
    });
  }

  // Check brand impersonation
  const mentionedBrands = Object.keys(OFFICIAL_BRANDS).filter(brand =>
    new RegExp(`\\b${brand}\\b`, "i").test(text)
  );

  if (mentionedBrands.length > 0) {
    const officialDomains = mentionedBrands.flatMap(b => OFFICIAL_BRANDS[b]);
    const unauthorizedDomains = [...detectedDomains].filter(d => !officialDomains.includes(d));
    if (unauthorizedDomains.length > 0 || freeEmailProviders.length > 0 || hasChatChannel) {
      flags.push({
        id: "imp",
        t: "Possible company impersonation",
        w: 30,
        s: 1,
        why: "The offer names a well-known brand (e.g. TCS, Infosys, Amazon), but contact details do not belong to their official corporate domain.",
        q: [...new Set([...mentionedBrands, ...unauthorizedDomains, ...freeEmailProviders])]
      });
    }
  }

  // Check email vs website mismatch
  if (email && website) {
    const emailParts = email.toLowerCase().split("@")[1] || "";
    const emailRoot = getRootDomain(emailParts);
    let webClean = website.replace(/^https?:\/\//i, "").split("/")[0].toLowerCase();
    const webRoot = getRootDomain(webClean);

    if (emailRoot && webRoot && emailRoot !== webRoot) {
      flags.push({
        id: "mis",
        t: "Email and website don’t match",
        w: 20,
        why: `Sender email (@${emailParts}) is on a different domain than the official website given (${webClean}).`,
        q: [emailParts, webClean]
      });
    }
  }

  // Check suspicious / disposable domain endings
  const suspiciousTldRegex = /\.(xyz|online|site|top|click|shop|work|biz|icu|buzz|cfd|sbs)$/i;
  const suspiciousDomains = [...detectedDomains].filter(d => suspiciousTldRegex.test(d));
  if (suspiciousDomains.length > 0) {
    flags.push({
      id: "tld",
      t: "Risky-looking domain",
      w: 15,
      why: "The domain uses a cheap or disposable extension frequently used for short-lived scam and phishing sites.",
      q: suspiciousDomains
    });
  }

  // Check missing employer details
  if (detectedDomains.size === 0 && !email && !website) {
    flags.push({
      id: "noinfo",
      t: "No employer details",
      w: 18,
      why: "No identifiable corporate website, business domain or corporate email was provided to verify the employer.",
      q: ["No company domain found"]
    });
  }

  // 3. Identify positive trust indicators (Good signs)
  const goodSigns = [];
  if (NEGATION_PATTERN.test(text) && /\b(fees?|charges?|money|deposit)\b/i.test(text)) {
    goodSigns.push("Explicitly states that no fees or charges are requested.");
  }
  if (/\b(assessment|technical interview|rounds|shortlist|portfolio)\b/i.test(text)) {
    goodSigns.push("Mentions a structured evaluation process (interview/test).");
  }
  if (detectedDomains.size > 0 && !freeEmailProviders.length && !hasChatChannel) {
    goodSigns.push(`Official domain used: ${[...detectedDomains].slice(0, 2).join(", ")}.`);
  }

  // 4. Calculate Risk Score & Level
  let rawScore = flags.reduce((acc, f) => acc + f.w, 0);
  const hasSevereFlag = flags.some(f => f.s === 1);

  // Severe red flags (fees, OTP, guaranteed placement) floor the score at 60
  let finalScore = hasSevereFlag ? Math.max(60, rawScore) : rawScore;
  finalScore = Math.min(100, Math.max(0, finalScore));

  const level = finalScore >= 50 ? "High" : finalScore >= 25 ? "Medium" : "Low";

  // 5. Generate Tailored Safety Recommendations
  const recommendations = [];
  if (flags.some(f => f.id === "pay")) {
    recommendations.push("NEVER transfer money, registration fees, or equipment security deposits. Legitimate hiring is always free.");
  }
  if (flags.some(f => f.id === "sens")) {
    recommendations.push("Do not provide bank passwords, UPI PINs, OTPs, or photos of ID cards before a verified formal contract.");
  }
  if (flags.some(f => f.id === "imp" || f.id === "ct" || f.id === "mis")) {
    recommendations.push("Cross-verify the recruiter by visiting the company’s official careers page or contacting their official switchboard.");
  }
  if (recommendations.length === 0) {
    if (finalScore >= 25) {
      recommendations.push("Proceed with caution. Request an official offer letter on corporate letterhead before sharing any documents.");
    } else {
      recommendations.push("Standard precaution: ensure all communications remain on official company channels.");
    }
  }

  return {
    score: finalScore,
    level, // "Low" | "Medium" | "High"
    flags,
    good: goodSigns,
    ranges,
    recommendations,
    checkedAt: new Date().toISOString()
  };
}

module.exports = {
  analyze,
  CRITERIA,
  OFFICIAL_BRANDS,
  FREE_EMAIL_DOMAINS
};
