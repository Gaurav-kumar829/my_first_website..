/**
 * OfferShield - Deepfake & Fake Interview Verification Route
 * Analyzes synthetic media indicators, suspicious interview behaviors, and image metadata
 */

const express = require('express');
const router = express.Router();
const multer = require('multer');

// Configure multer for in-memory processing (Never write malicious files to disk)
const upload = multer({
  limits: {
    fileSize: 8 * 1024 * 1024 // 8 MB max
  }
});

// Checklist cues for suspicious video/audio interview signs
const CUES = [
  { id: "sync", w: 3, text: "Lip movement and voice didn’t match", why: "Face-swap and voice-clone tools often lag behind or de-synchronize from real-time audio." },
  { id: "edge", w: 3, text: "Face edges blurred or flickered when the head turned or a hand passed in front", why: "Real-time AI deepfake filters struggle with occlusions, profile angles, and boundary blending." },
  { id: "refuse", w: 4, text: "They refused to turn sideways, wave a hand across their face or show an ID when asked", why: "A legitimate human recruiter can easily do this in seconds. Refusal is an immediate warning." },
  { id: "nocam", w: 2, text: "Camera was off or audio-only, with a “network issue” excuse", why: "Fraudsters avoid showing real faces that could be cross-matched or identified." },
  { id: "voice", w: 2, text: "The voice sounded flat or robotic, or the same background noise looped", why: "Cloned or text-to-speech audio often has artificial pitch contours and synthetic artifacts." },
  { id: "remote", w: 4, text: "They asked you to install AnyDesk, TeamViewer or another remote-access app", why: "Critical red flag: granting remote access compromises your local credentials and system." },
  { id: "link", w: 3, text: "The meeting link wasn’t Zoom, Google Meet or Teams, or used a look-alike domain", why: "Phishing links impersonating conferencing services are used to harvest logins or deploy malware." },
  { id: "profile", w: 2, text: "The recruiter’s photo looked too perfect and the profile was new or had few connections", why: "AI-generated personas and fresh profiles are standard tools for impersonators." },
  { id: "money", w: 4, text: "They asked for money, documents or bank details during or after the call", why: "No real hiring team asks for deposits, card details, or sensitive IDs during an interview." },
  { id: "quick", w: 2, text: "You were selected within minutes after a few generic questions", why: "Instant selection without skill evaluation is bait for an advance-fee fraud." }
];

const ADVICE = [
  "Ask the interviewer to turn their head sideways and wave a hand across their face on live camera.",
  "Cross-verify the recruiter's identity by calling the company's verified telephone number listed on their official website.",
  "Never install remote-access software (AnyDesk, TeamViewer) or share banking passwords/OTPs during an interview.",
  "Report suspicious impersonators at cybercrime.gov.in or the national helpline 1930."
];

/**
 * Heuristic interview assessment
 */
function evaluateInterview(ids) {
  const selectedIds = Array.isArray(ids) ? ids : [];
  const matched = CUES.filter(c => selectedIds.includes(c.id));
  const score = matched.reduce((sum, c) => sum + c.w, 0);
  const maxScore = CUES.reduce((sum, c) => sum + c.w, 0);

  const level = score >= 10 ? "High" : score >= 5 ? "Medium" : "Low";

  return {
    score,
    max: maxScore,
    level,
    flags: matched.map(({ text, why, w }) => ({ text, why, w })),
    advice: ADVICE,
    disclaimer: "Notice: This checklist-based assessment evaluates behavioral risk factors and does not provide mathematical or forensic proof of deepfake manipulation."
  };
}

/**
 * Image metadata & header forensics
 * Inspects file signatures, EXIF headers, and generative AI traces
 */
function inspectImageBuffer(buf) {
  if (!buf || buf.length < 16) {
    return { error: "File buffer is too small or invalid." };
  }

  // Detect format
  let kind = null;
  if (buf[0] === 0xFF && buf[1] === 0xD8) {
    kind = "JPEG";
  } else if (buf.slice(0, 4).toString("latin1") === "\x89PNG") {
    kind = "PNG";
  } else if (buf.slice(0, 4).toString("latin1") === "RIFF" && buf.slice(8, 12).toString("latin1") === "WEBP") {
    kind = "WebP";
  }

  if (!kind) {
    return { error: "Please upload a valid JPEG, PNG, or WebP image." };
  }

  // Dimensions
  let width = 0;
  let height = 0;
  if (kind === "PNG" && buf.length > 24) {
    width = buf.readUInt32BE(16);
    height = buf.readUInt32BE(20);
  } else if (kind === "JPEG") {
    let i = 2;
    while (i < buf.length - 9) {
      if (buf[i] !== 0xFF) { i++; continue; }
      const marker = buf[i + 1];
      if (marker === 0xFF) { i++; continue; }
      if (marker >= 0xC0 && marker <= 0xC3) {
        height = buf.readUInt16BE(i + 5);
        width = buf.readUInt16BE(i + 7);
        break;
      }
      if (marker === 0xD8 || marker === 0x01 || (marker >= 0xD0 && marker <= 0xD7)) {
        i += 2;
        continue;
      }
      const len = buf.readUInt16BE(i + 2);
      if (len < 2) break;
      i += 2 + len;
    }
  }

  const headerStr = buf.slice(0, 262144).toString("latin1");
  const indicators = [];
  const good = [];
  let score = 0;

  const add = (text, strength, pts, evidence) => {
    indicators.push({ text, strength, evidence });
    score += pts;
  };

  // 1. Known AI model generation markers
  const genMatch = headerStr.match(/Stable Diffusion|Midjourney|DALL[-·]E|Adobe Firefly|ComfyUI|NovelAI|Leonardo\.Ai|trainedAlgorithmicMedia/i);
  if (genMatch) {
    add("AI-generation marker found in metadata", "Strong", 60, genMatch[0]);
  }

  if (/Steps:\s*\d+,\s*Sampler:/i.test(headerStr)) {
    add("Diffusion generation parameters embedded in metadata", "Strong", 60, "Steps / Sampler prompt parameters detected");
  }

  if (headerStr.includes("c2pa") && headerStr.includes("jumb") && !genMatch) {
    add("Content Credentials (C2PA) manifest present", "Medium", 20, "C2PA provenance manifest attached");
  }

  // 2. Face editing / enhancement apps
  const faceApp = headerStr.match(/FaceApp|Facetune|Remini|Lensa|Picsart/i);
  if (faceApp) {
    add("Processed using portrait/face alteration software", "Medium", 30, faceApp[0]);
  }

  const editorApp = headerStr.match(/Adobe Photoshop|Photoshop|GIMP|Canva|Snapseed|Lightroom|Pixelmator/i);
  if (editorApp && !faceApp) {
    add("Modified using graphic editing application", "Medium", 15, editorApp[0]);
  }

  // 3. Camera EXIF indicators
  const cameraMatch = headerStr.match(/Canon|NIKON|SONY|Apple|SAMSUNG|samsung|Google|Xiaomi|OnePlus|vivo|OPPO|Huawei|FUJIFILM|Panasonic/);
  const hasExif = headerStr.includes("Exif\0\0");
  if (kind === "JPEG" && hasExif && cameraMatch) {
    good.push(`Authentic camera hardware signature found (${cameraMatch[0]})`);
  } else if (kind === "JPEG" && !hasExif) {
    add("Absence of camera EXIF metadata in JPEG", "Weak", 15, "Standard photographic EXIF block absent");
  }

  // 4. Square resolution typical of older diffusion models
  if (width && width === height && [512, 640, 768, 1024, 1536, 2048].includes(width)) {
    add("Square aspect ratio common in synthetic generators", "Weak", 15, `${width}×${height} pixels`);
  }

  score = Math.min(100, score);
  const level = score >= 50 ? "High" : score >= 20 ? "Medium" : "Low";

  return {
    kind,
    width,
    height,
    sizeKB: Math.round(buf.length / 1024),
    score,
    level,
    indicators,
    good,
    disclaimer: "Disclaimer: Header and metadata inspection reveals software signatures and EXIF data when present. Stripping metadata does not prove authenticity, nor does absence of metadata alone prove an image is AI-generated."
  };
}

/**
 * GET /api/deepfake/cues
 * Returns the checklist cues
 */
router.get('/cues', (req, res) => {
  return res.json(CUES.map(({ id, text }) => ({ id, text })));
});

/**
 * POST /api/deepfake/check (and POST /api/deepfake/interview)
 * Assesses interview checklist signs
 */
router.post(['/check', '/interview'], (req, res) => {
  const ids = (req.body && req.body.ids) || [];
  const assessment = evaluateInterview(ids);
  return res.json(assessment);
});

/**
 * POST /api/deepfake/image
 * Inspects image files for AI tags and EXIF integrity
 */
router.post('/image', upload.single('file'), (req, res) => {
  try {
    let buffer = null;

    if (req.file && req.file.buffer) {
      buffer = req.file.buffer;
    } else if (Buffer.isBuffer(req.body)) {
      buffer = req.body;
    } else if (req.rawBody && Buffer.isBuffer(req.rawBody)) {
      buffer = req.rawBody;
    }

    if (!buffer || buffer.length === 0) {
      return res.status(400).json({
        error: "No image file received. Please upload a JPEG, PNG or WebP image up to 8 MB."
      });
    }

    const report = inspectImageBuffer(buffer);
    if (report.error) {
      return res.status(400).json(report);
    }

    return res.json(report);
  } catch (err) {
    console.error("Deepfake image scan error:", err);
    return res.status(500).json({ error: "Failed to inspect image file." });
  }
});

module.exports = router;
