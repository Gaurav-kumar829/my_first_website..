/**
 * OfferShield - Phishing Simulation Route
 * Safe, interactive training modules to help students spot deceptive job offers
 */

const express = require('express');
const router = express.Router();

// Safe educational simulation scenarios
const SCENARIOS = [
  {
    id: 1,
    channel: "WhatsApp",
    from: "+91 98•••• 21 (Priya, Global Careers HR)",
    subject: "",
    lines: [
      "Hi! I’m Priya from Global Careers HR.",
      "Congratulations, you are shortlisted for a work-from-home internship with ₹45,000 per week salary.",
      "No interview needed. Selection is 100% guaranteed.",
      "Pay a ₹1,200 refundable registration fee to this UPI ID to block your seat.",
      "Only 3 seats left. Reply within 2 hours!"
    ],
    red: [1, 2, 3, 4],
    scam: true,
    why: "Massive pay, no interview evaluation, an upfront registration fee and artificial countdown urgency are the classic scam combination. Real companies never charge job applicants."
  },
  {
    id: 2,
    channel: "Email",
    from: "careers@acmeanalytics.com",
    subject: "Your Data Analyst Intern application",
    lines: [
      "Thank you for applying for the Data Analyst Intern role at Acme Analytics Pvt. Ltd.",
      "Your resume has been shortlisted. Please pick a slot for a 30-minute video interview on our careers portal.",
      "There is no fee at any stage of our hiring process.",
      "Reply to this email if you need help with scheduling."
    ],
    red: [],
    scam: false,
    why: "Sent from the company's own official domain, outlines an interview screening process, asks for zero sensitive information and explicitly states no fee is required."
  },
  {
    id: 3,
    channel: "Email",
    from: "hr.infosys.offers@gmail.com",
    subject: "Internship offer letter",
    lines: [
      "Dear candidate, we are delighted to offer you an internship at Infosys.",
      "To generate your offer letter, reply with photos of your Aadhaar and PAN card.",
      "Accept within 24 hours or the offer will be cancelled."
    ],
    red: [1, 2],
    scam: true,
    why: "Major IT companies never email from free Gmail accounts. Demanding Aadhaar/PAN cards before issuing an official letter with an artificial 24-hour ultimatum is an identity theft trap."
  },
  {
    id: 4,
    channel: "LinkedIn message",
    from: "Rahul Mehta, Recruiter at BrightWave Media",
    subject: "",
    lines: [
      "Hi Ananya, I saw your portfolio and liked your campaign work.",
      "We have a paid marketing internship in Pune with a stipend of ₹8,000 per month.",
      "If you are interested, apply at brightwavemedia.in/careers and I will schedule an interview."
    ],
    red: [],
    scam: false,
    why: "Reasonable market-standard stipend, a legitimate business domain, and a transparent procedure pointing to their careers portal."
  },
  {
    id: 5,
    channel: "SMS",
    from: "VM-INTERN",
    subject: "",
    lines: [
      "Dear student, your internship stipend of ₹10,000 is on hold.",
      "Verify your bank details at bit.ly/intern-verify-now to receive it.",
      "Share the OTP sent to your phone to complete verification."
    ],
    red: [1, 2],
    scam: true,
    why: "Shortened links hide malicious phishing destinations, and genuine recruiters NEVER ask for an OTP or online banking credentials."
  },
  {
    id: 6,
    channel: "Telegram",
    from: "HR Desk (new account)",
    subject: "Interview schedule",
    lines: [
      "Your interview is fixed. Join at meet-google-hr.xyz/room.",
      "Keep your camera on and install AnyDesk so our team can verify your laptop.",
      "Our recruiter will join with the camera off because of network issues."
    ],
    red: [0, 1, 2],
    scam: true,
    why: "The URL is a fake typo-squatted domain, installing remote-access software gives attackers full control of your device, and refusing to turn on camera hides their fake identity."
  }
];

// Helper to get client-safe simulation list (excludes answers)
function getSafeSimulationList() {
  return SCENARIOS.map(({ id, channel, from, subject, lines }) => ({
    id,
    channel,
    from,
    subject,
    lines
  }));
}

// Helper to evaluate answer
function checkSimulationAnswer(body) {
  const { id, verdict, picked = [] } = body || {};
  const scenario = SCENARIOS.find(s => s.id === Number(id));

  if (!scenario) {
    return { error: "Unknown simulation scenario ID." };
  }

  const userPicked = Array.isArray(picked) ? picked.map(Number) : [];
  const isVerdictCorrect = (verdict === "scam") === scenario.scam;

  return {
    correct: isVerdictCorrect,
    scam: scenario.scam,
    red: scenario.red,
    total: scenario.red.length,
    hit: userPicked.filter(i => scenario.red.includes(i)).length,
    why: scenario.why
  };
}

/**
 * GET /api/simulations (and GET /api/drill)
 * Returns the list of phishing simulations
 */
router.get(['/simulations', '/drill'], (req, res) => {
  return res.json(getSafeSimulationList());
});

/**
 * POST /api/simulations/check (and POST /api/drill/answer)
 * Evaluates the candidate's answer and highlighted suspicious lines
 */
router.post(['/simulations/check', '/drill/answer'], (req, res) => {
  const result = checkSimulationAnswer(req.body);
  if (result.error) {
    return res.status(400).json(result);
  }
  return res.json(result);
});

module.exports = router;
