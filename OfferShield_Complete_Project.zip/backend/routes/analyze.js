/**
 * OfferShield - Analyze Route
 * Endpoints for detecting scam patterns in job/internship offers
 */

const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { analyze, CRITERIA } = require('../services/riskAnalyzer');

const HISTORY_FILE = path.join(__dirname, '../data/history.json');
const reportedDomains = new Set(['infosys-careers.xyz', 'tcs-hiring.top', 'amazon-apply.site']);

// Helper to save scan to history.json
function saveScanToHistory(record) {
  try {
    let history = [];
    if (fs.existsSync(HISTORY_FILE)) {
      const data = fs.readFileSync(HISTORY_FILE, 'utf8');
      history = JSON.parse(data || '[]');
    }
    history.unshift(record);
    // Keep last 100 scans to avoid uncontrolled growth
    if (history.length > 100) history = history.slice(0, 100);
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
  } catch (err) {
    console.error('Error saving history:', err.message);
  }
}

/**
 * POST /api/analyze
 * Analyzes offer text, email, and website for scam indicators
 */
router.post('/analyze', (req, res) => {
  try {
    const { text = '', email = '', website = '' } = req.body || {};

    if (!text && !email && !website) {
      return res.status(400).json({
        error: 'Please provide job offer text, sender email, or company website to analyze.'
      });
    }

    // Limit text to 20,000 chars for safety
    const cleanText = String(text).slice(0, 20000);
    const cleanEmail = String(email).slice(0, 300);
    const cleanWebsite = String(website).slice(0, 300);

    const result = analyze(cleanText, cleanEmail, cleanWebsite, reportedDomains);

    // Save anonymized summary to scan history
    const snippet = cleanText
      ? cleanText.slice(0, 90).replace(/\s+/g, ' ') + (cleanText.length > 90 ? '...' : '')
      : cleanEmail || cleanWebsite || 'Offer check';

    saveScanToHistory({
      id: `scan-${Date.now()}`,
      date: new Date().toISOString(),
      type: 'offer',
      snippet,
      riskScore: result.score,
      riskLevel: result.level,
      reasonsCount: result.flags.length,
      verdict: result.level === 'High' ? 'High Risk' : result.level === 'Medium' ? 'Caution' : 'Safe / Low Risk'
    });

    return res.json(result);
  } catch (error) {
    console.error('Analysis error:', error);
    return res.status(500).json({
      error: 'An unexpected error occurred while analyzing the offer. Please try again.'
    });
  }
});

/**
 * GET /api/criteria
 * Returns the transparent scoring criteria and weighted warning signals
 */
router.get('/criteria', (req, res) => {
  return res.json(CRITERIA);
});

/**
 * POST /api/report
 * Allows users to report fraudulent domains to protect the community
 */
router.post('/report', (req, res) => {
  const { domain } = req.body || {};
  if (domain && typeof domain === 'string') {
    const clean = domain.trim().toLowerCase().replace(/^https?:\/\//i, '').split('/')[0];
    reportedDomains.add(clean);
  }
  return res.json({
    message: 'Thank you for your report! OfferShield uses community intelligence to flag repeat scam domains.'
  });
});

module.exports = router;
