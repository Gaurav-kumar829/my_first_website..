/**
 * OfferShield - Link & File Scanner Route
 * Multi-Engine URL and File Threat Analysis (VirusTotal-style architecture)
 */

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { analyze } = require('../services/riskAnalyzer');

const HISTORY_FILE = path.join(__dirname, '../data/history.json');
const BAD_HASHES_FILE = path.join(__dirname, '../data/bad_hashes.txt');

// Load known bad hashes safely
const BAD_HASHES = new Set();
try {
  if (fs.existsSync(BAD_HASHES_FILE)) {
    fs.readFileSync(BAD_HASHES_FILE, 'utf8')
      .split(/\s+/)
      .filter(x => x.length === 64)
      .forEach(x => BAD_HASHES.add(x.toLowerCase()));
  }
} catch (e) {
  console.warn('Could not read bad_hashes.txt:', e.message);
}

const OFFICIAL_BRANDS = {
  tcs: ["tcs.com"],
  infosys: ["infosys.com"],
  wipro: ["wipro.com"],
  amazon: ["amazon.com", "amazon.in", "amazon.jobs"],
  deloitte: ["deloitte.com"],
  accenture: ["accenture.com"],
  flipkart: ["flipkart.com"],
  google: ["google.com", "withgoogle.com"],
  microsoft: ["microsoft.com"],
  linkedin: ["linkedin.com"],
  naukri: ["naukri.com"],
  internshala: ["internshala.com"],
  indeed: ["indeed.com", "indeed.co.in"],
  paytm: ["paytm.com"],
  phonepe: ["phonepe.com"]
};

const SHORTENERS = new Set([
  "bit.ly", "tinyurl.com", "t.co", "goo.gl", "cutt.ly",
  "rb.gy", "is.gd", "shorturl.at", "ow.ly", "tiny.cc", "bl.ink", "rebrand.ly"
]);

const SUSPICIOUS_TLD = /\.(xyz|top|online|site|click|shop|work|biz|icu|buzz|live|cfd|sbs)$/i;
const FREE_HOSTING = /(blogspot|weebly|wixsite|netlify\.app|github\.io|vercel\.app|000webhostapp|firebaseapp|web\.app|herokuapp|glitch\.me|pages\.dev)/i;

const E = (engine, verdict, detail) => ({ engine, verdict, detail });

function getRootDomain(host) {
  if (!host) return "";
  const parts = host.toLowerCase().split(".");
  if (parts.length >= 3 && /\.(co|org|ac|gov|net)\.in$/i.test(host)) {
    return parts.slice(-3).join(".");
  }
  return parts.slice(-2).join(".");
}

// Levenshtein distance for typo-squatting detection
function levenshtein(a, b) {
  const matrix = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
  for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return matrix[a.length][b.length];
}

function calculateVerdict(engines) {
  const maliciousCount = engines.filter(e => e.verdict === "malicious").length;
  const suspiciousCount = engines.filter(e => e.verdict === "suspicious").length;
  const flagged = maliciousCount + suspiciousCount;
  const verdict = (maliciousCount > 0 || suspiciousCount >= 3)
    ? "Dangerous"
    : suspiciousCount >= 1
      ? "Suspicious"
      : "Clean";

  return { flagged, total: engines.length, verdict };
}

/**
 * Scan URL through 8 security engines
 */
function scanUrl(input, reported = new Set()) {
  let u = String(input || "").trim();
  if (!u || u.length > 2000) {
    return { error: "Please enter a valid link or domain (up to 2000 characters)." };
  }

  if (/^(javascript|data):/i.test(u)) {
    const en = [E("Protocol Inspector", "malicious", "Script or data URLs run executable code inside browser context.")];
    return { url: u.slice(0, 100), meta: "Non-web protocol link", engines: en, ...calculateVerdict(en) };
  }

  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) {
    u = "https://" + u;
  }

  let parsedUrl;
  try {
    parsedUrl = new URL(u);
  } catch (err) {
    return { error: "Invalid URL syntax. Please enter a proper web link." };
  }

  const host = parsedUrl.hostname.toLowerCase();
  const root = getRootDomain(host);
  const label = root.split(".")[0];
  const parts = host.split(".").slice(0, -1);
  const engines = [];

  // 1. Lexical Analyzer
  const lexicalIssues = [];
  if (u.length > 85) lexicalIssues.push("Unusually long URL length");
  if (u.includes("@")) lexicalIssues.push("Contains '@' symbol which can conceal destination host");
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) lexicalIssues.push("Raw IP address used instead of domain");
  if (host.split(".").length > 4) lexicalIssues.push("Excessive subdomains");
  if ((host.match(/-/g) || []).length >= 3) lexicalIssues.push("Multiple hyphens in domain");
  if ((label.match(/\d/g) || []).length >= 3 && /[a-z]/.test(label)) lexicalIssues.push("Alphanumeric confusion (digits interspersed in brand name)");

  engines.push(E("Lexical Analyzer", lexicalIssues.length ? "suspicious" : "clean", lexicalIssues.length ? lexicalIssues.join("; ") : "URL structure looks normal."));

  // 2. TLD & Hosting Reputation
  const repIssues = [];
  if (SUSPICIOUS_TLD.test(host)) repIssues.push("Disposable/cheap TLD commonly used in phishing");
  if (FREE_HOSTING.test(host)) repIssues.push("Free shared hosting service frequently abused for scam pages");
  engines.push(E("TLD and Hosting Reputation", repIssues.length ? "suspicious" : "clean", repIssues.length ? repIssues.join("; ") : "Domain TLD and hosting infrastructure look standard."));

  // 3. Brand Lookalike Detector
  let official = false;
  let brandHit = null;
  let severity = "suspicious";
  const normalizedLabel = label.replace(/0/g, "o").replace(/1/g, "l").replace(/3/g, "e").replace(/5/g, "s").replace(/-/g, "");

  for (const [brand, domains] of Object.entries(OFFICIAL_BRANDS)) {
    if (domains.includes(root)) {
      official = true;
      brandHit = brand;
      break;
    }
    if (label.split("-").includes(brand) || parts.slice(0, -1).includes(brand) || normalizedLabel === brand) {
      brandHit = brand;
      severity = "malicious";
      break;
    }
    if (brand.length >= 5 && levenshtein(normalizedLabel, brand) <= 1) {
      brandHit = brand;
      break;
    }
  }

  engines.push(
    official
      ? E("Brand Lookalike Detector", "clean", `Verified official domain of ${brandHit}.`)
      : brandHit
        ? E("Brand Lookalike Detector", severity, `Imitates ${brandHit} without being their official domain.`)
        : E("Brand Lookalike Detector", "clean", "No brand typo-squatting or lookalike pattern detected.")
  );

  // 4. Homograph / Punycode Detector
  const isPunycode = host.includes("xn--") || /[^\x00-\x7F]/.test(u);
  engines.push(E("Homograph Detector", isPunycode ? "suspicious" : "clean", isPunycode ? "Contains look-alike non-ASCII internationalized characters (punycode)." : "Standard ASCII domain characters."));

  // 5. Shortener Check
  const isShortener = SHORTENERS.has(host);
  engines.push(E("URL Shortener Check", isShortener ? "suspicious" : "clean", isShortener ? "Shortened link obscures final target destination." : "Standard non-shortened URL."));

  // 6. Hiring-Scam Keywords
  const combinedPath = (host + parsedUrl.pathname).toLowerCase();
  const hasScamKeywords = /(job|career|hiring|recruit|intern|offer|placement)/.test(combinedPath) &&
    /(fee|pay|payment|register|registration|verify|kyc|deposit|apply-?now|login)/.test(combinedPath) &&
    !official;
  engines.push(E("Hiring-Scam Keywords", hasScamKeywords ? "suspicious" : "clean", hasScamKeywords ? "Combines job terms with payment/credential harvesting cues." : "No scam keyword combinations found."));

  // 7. Protocol and Download Inspector
  const protocolIssues = [];
  let isMalicious = false;
  if (parsedUrl.protocol === "http:") protocolIssues.push("Unencrypted HTTP connection");
  if (parsedUrl.port && !["80", "443"].includes(parsedUrl.port)) protocolIssues.push(`Non-standard port ${parsedUrl.port}`);
  if (/\.(exe|apk|scr|bat|msi|jar|vbs|ps1|iso|hta|lnk)$/i.test(parsedUrl.pathname)) {
    protocolIssues.push("Direct executable download link");
    isMalicious = true;
  }
  engines.push(E("Protocol and Download Inspector", isMalicious ? "malicious" : protocolIssues.length ? "suspicious" : "clean", protocolIssues.length ? protocolIssues.join("; ") : "HTTPS secured, standard port, no direct binary download."));

  // 8. Community Reports
  const isReported = reported.has(root) || reported.has(host);
  engines.push(E("OfferShield Community Reports", isReported ? "malicious" : "clean", isReported ? "Flagged as fraudulent by multiple OfferShield community reports." : "Zero community fraud reports recorded."));

  return {
    url: parsedUrl.href,
    meta: `Host: ${host} · Registered domain: ${root}`,
    engines,
    ...calculateVerdict(engines)
  };
}

/**
 * Scan File Buffer through 8 security engines
 */
function scanFile(buf, filename = "attachment", reported = new Set()) {
  const safeName = String(filename || "file").slice(0, 200);
  const ext = (safeName.split(".").pop() || "").toLowerCase();

  const hashSum = algo => crypto.createHash(algo).update(buf).digest("hex");
  const hashes = {
    md5: hashSum("md5"),
    sha1: hashSum("sha1"),
    sha256: hashSum("sha256")
  };

  const textSample = buf.slice(0, 1048576).toString("latin1");
  const engines = [];
  let detectedType = "Unknown";
  const b = buf;

  // Identify true file magic numbers
  if (b.length >= 2 && b[0] === 0x4D && b[1] === 0x5A) detectedType = "Windows executable";
  else if (textSample.startsWith("\x7fELF")) detectedType = "Linux executable";
  else if (textSample.startsWith("%PDF")) detectedType = "PDF";
  else if (b.length >= 4 && b[0] === 0xD0 && b[1] === 0xCF && b[2] === 0x11 && b[3] === 0xE0) detectedType = "Legacy Office (OLE)";
  else if (textSample.startsWith("PK\x03\x04")) {
    detectedType = /AndroidManifest\.xml/.test(textSample) ? "Android package" : /word\/|xl\/|ppt\//.test(textSample) ? "Office Open XML" : "ZIP archive";
  }
  else if (b.length >= 2 && b[0] === 0xFF && b[1] === 0xD8) detectedType = "JPEG";
  else if (textSample.startsWith("\x89PNG")) detectedType = "PNG";
  else if (/^(#!|\s*<script|\s*@echo off)/i.test(textSample.slice(0, 200))) detectedType = "Script";
  else if (((textSample.slice(0, 4096).match(/[\x09\x0A\x0D\x20-\x7E]/g) || []).length) / Math.max(1, Math.min(textSample.length, 4096)) > 0.95) detectedType = "Text";

  const EXPECTED_MAPPINGS = {
    pdf: ["PDF"],
    doc: ["Legacy Office (OLE)"],
    xls: ["Legacy Office (OLE)"],
    docx: ["Office Open XML"],
    xlsx: ["Office Open XML"],
    pptx: ["Office Open XML"],
    docm: ["Office Open XML"],
    xlsm: ["Office Open XML"],
    jpg: ["JPEG"],
    jpeg: ["JPEG"],
    png: ["PNG"],
    zip: ["ZIP archive"],
    txt: ["Text"],
    csv: ["Text"]
  };

  const EXECUTABLE_TYPES = ["Windows executable", "Linux executable", "Android package"];
  const isExecExt = /^(exe|dll|apk|scr|com|msi|bin|elf)$/i.test(ext);

  // 1. File Signature Analyzer
  if (EXECUTABLE_TYPES.includes(detectedType) && !isExecExt) {
    engines.push(E("File Signature Analyzer", "malicious", `Actual payload is a ${detectedType} disguised with a .${ext} extension.`));
  } else if (EXPECTED_MAPPINGS[ext] && detectedType !== "Unknown" && !EXPECTED_MAPPINGS[ext].includes(detectedType) && detectedType !== "Text") {
    engines.push(E("File Signature Analyzer", "suspicious", `Internal byte signature represents ${detectedType}, mismatched with extension .${ext}.`));
  } else {
    engines.push(E("File Signature Analyzer", "clean", `Detected ${detectedType}; matches declared file extension.`));
  }

  // 2. Extension Policy
  const isDoubleExtension = /\.(pdf|docx?|xlsx?|jpe?g|png|txt)\.(exe|scr|bat|cmd|js|vbs|lnk|com|jar)$/i.test(safeName);
  engines.push(
    isDoubleExtension
      ? E("Extension Policy", "malicious", "Dangerous double extension used to camouflage an executable binary.")
      : /^(exe|scr|bat|cmd|com|msi|jar|js|vbs|ps1|apk|lnk|iso|hta|dll|pif)$/i.test(ext)
        ? E("Extension Policy", "malicious", "Executables, scripts and installer packages are never valid job offer letters.")
        : /^(docm|xlsm|pptm|xlsb)$/i.test(ext)
          ? E("Extension Policy", "suspicious", "Macro-enabled Microsoft Office format.")
          : E("Extension Policy", "clean", "Standard office document or image extension.")
  );

  // 3. Office Macro Scanner
  if (detectedType === "Office Open XML") {
    engines.push(/vbaProject\.bin/.test(textSample) ? E("Office Macro Scanner", "suspicious", "Contains VBA macro code. Genuine offer letters never require enabling macros.") : E("Office Macro Scanner", "clean", "No active macros found."));
  } else if (detectedType === "Legacy Office (OLE)") {
    const hasVba = /(AutoOpen|Document_Open|Workbook_Open|Auto_Open)/i.test(textSample) && /(Shell|CreateObject|WScript|powershell)/i.test(textSample);
    engines.push(hasVba ? E("Office Macro Scanner", "malicious", "Contains auto-executing VBA macros with process execution commands.") : E("Office Macro Scanner", "clean", "No suspicious macros detected."));
  } else {
    engines.push(E("Office Macro Scanner", "clean", "Non-Office format (no macro capability)."));
  }

  // 4. PDF Exploit & Action Scanner
  if (detectedType === "PDF") {
    const pdfIssues = [];
    if (/\/JavaScript|\/JS\b/.test(textSample)) pdfIssues.push("Embedded JavaScript code");
    if (/\/Launch\b/.test(textSample)) pdfIssues.push("Auto-launch action payload");
    if (/\/EmbeddedFiles\b/.test(textSample)) pdfIssues.push("Embedded secondary file payload");
    engines.push(pdfIssues.length ? E("PDF Exploit Scanner", "malicious", `Suspicious PDF elements: ${pdfIssues.join(", ")}.`) : E("PDF Exploit Scanner", "clean", "Standard static PDF elements."));
  } else {
    engines.push(E("PDF Exploit Scanner", "clean", "Not a PDF document."));
  }

  // 5. Payload String Scanner
  const payloadPatterns = [
    /powershell(\.exe)?\s+-(enc|e|w\s*hidden|nop)/i,
    /cmd(\.exe)?\s*\/c/i,
    /WScript\.Shell/i,
    /FromBase64String/i,
    /Invoke-Expression|\bIEX\s*\(/i,
    /certutil\s+-urlcache/i,
    /\bmshta\s/i,
    /\bregsvr32\s/i,
    /eval\s*\(\s*(unescape|atob)/i
  ];
  const payloadHits = payloadPatterns.filter(p => p.test(textSample)).length;
  engines.push(
    payloadHits >= 2
      ? E("Payload String Scanner", "malicious", `${payloadHits} command-line execution patterns detected.`)
      : payloadHits === 1
        ? E("Payload String Scanner", "suspicious", "Potential shell execution pattern discovered.")
        : E("Payload String Scanner", "clean", "Zero command-execution artifacts found.")
  );

  // 6. Hash & Test Signature Check
  engines.push(
    BAD_HASHES.has(hashes.sha256)
      ? E("Hash & Test Signature Check", "malicious", "SHA-256 matches known malicious signature repository.")
      : /EICAR-STANDARD-ANTIVIRUS-TEST-FILE/.test(textSample)
        ? E("Hash & Test Signature Check", "malicious", "Standard EICAR antivirus test file detected.")
        : E("Hash & Test Signature Check", "clean", "File hash clear of known threat records.")
  );

  // 7. Embedded Link Inspector
  const links = [...new Set(textSample.match(/https?:\/\/[^\s"'<>)\\]{4,200}/gi) || [])].slice(0, 5);
  const scannedLinks = links.map(l => ({ link: l, res: scanUrl(l, reported) })).filter(x => !x.res.error);
  const dangerousLinks = scannedLinks.filter(x => x.res.verdict === "Dangerous");
  const suspiciousLinks = scannedLinks.filter(x => x.res.verdict === "Suspicious");

  engines.push(
    dangerousLinks.length
      ? E("Embedded Link Inspector", "malicious", `${dangerousLinks.length} dangerous link(s) embedded: ${dangerousLinks.map(x => x.link.slice(0, 50)).join(", ")}`)
      : suspiciousLinks.length
        ? E("Embedded Link Inspector", "suspicious", `${suspiciousLinks.length} suspicious link(s) embedded.`)
        : E("Embedded Link Inspector", "clean", scannedLinks.length ? `${scannedLinks.length} link(s) inspected, no active threats.` : "No external links present.")
  );

  // 8. Offer Content Analyzer
  const extractedWords = ["Text", "Script", "PDF"].includes(detectedType)
    ? (buf.slice(0, 262144).toString("latin1").match(/[\x20-\x7E]{6,}/g) || []).join(" ")
    : "";

  if (extractedWords.length >= 40) {
    const offerAnalysis = analyze(extractedWords, "", "", reported);
    engines.push(
      offerAnalysis.score >= 50
        ? E("Offer Content Analyzer", "malicious", `Scam markers in document text: ${offerAnalysis.flags.slice(0, 3).map(f => f.t).join(", ")}`)
        : offerAnalysis.score >= 25
          ? E("Offer Content Analyzer", "suspicious", `Warning signs in text: ${offerAnalysis.flags.slice(0, 3).map(f => f.t).join(", ")}`)
          : E("Offer Content Analyzer", "clean", "Text content reflects genuine offer format.")
    );
  } else {
    engines.push(E("Offer Content Analyzer", "clean", "No extractable text content to inspect."));
  }

  return {
    meta: `${detectedType} · ${Math.max(1, Math.round(buf.length / 1024))} KB · ${safeName}`,
    hashes,
    engines,
    ...calculateVerdict(engines),
    disclaimer: "Disclaimer: Multi-engine heuristics examine structural integrity, magic numbers, and embedded strings. Static file scanning does not guarantee that a file is completely malware-free."
  };
}

// Multer memory storage (8MB limit)
const uploadMemory = multer({
  limits: { fileSize: 8 * 1024 * 1024 }
});

// Helper to save scan history
function recordScanHistory(type, target, verdict, score) {
  try {
    let history = [];
    if (fs.existsSync(HISTORY_FILE)) {
      history = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8') || '[]');
    }
    history.unshift({
      id: `scan-${Date.now()}`,
      date: new Date().toISOString(),
      type,
      snippet: target.slice(0, 80),
      riskScore: score,
      riskLevel: verdict === "Dangerous" ? "High" : verdict === "Suspicious" ? "Medium" : "Low",
      reasonsCount: 1,
      verdict
    });
    if (history.length > 100) history = history.slice(0, 100);
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
  } catch (err) {
    console.error("Error recording scan history:", err.message);
  }
}

/**
 * POST /api/scan/url
 */
router.post('/url', (req, res) => {
  try {
    const { url } = req.body || {};
    if (!url) {
      return res.status(400).json({ error: "Please enter a URL or web domain to scan." });
    }

    const report = scanUrl(url);
    if (report.error) {
      return res.status(400).json(report);
    }

    const score = report.verdict === "Dangerous" ? 85 : report.verdict === "Suspicious" ? 45 : 10;
    recordScanHistory("url", report.url, report.verdict, score);

    return res.json(report);
  } catch (err) {
    console.error("URL scan error:", err);
    return res.status(500).json({ error: "An error occurred while scanning the URL." });
  }
});

/**
 * POST /api/scan/file
 * Accepts raw binary stream or multipart file
 */
router.post('/file', uploadMemory.single('file'), (req, res) => {
  try {
    let buffer = null;
    let filename = "document";

    if (req.file && req.file.buffer) {
      buffer = req.file.buffer;
      filename = req.file.originalname || filename;
    } else if (Buffer.isBuffer(req.body)) {
      buffer = req.body;
      const headerName = req.headers['x-filename'];
      if (headerName) {
        try {
          filename = decodeURIComponent(headerName);
        } catch (e) {
          filename = String(headerName);
        }
      }
    } else if (req.rawBody && Buffer.isBuffer(req.rawBody)) {
      buffer = req.rawBody;
      const headerName = req.headers['x-filename'];
      if (headerName) {
        try {
          filename = decodeURIComponent(headerName);
        } catch (e) {
          filename = String(headerName);
        }
      }
    }

    if (!buffer || buffer.length === 0) {
      return res.status(400).json({
        error: "No file content received. Please select an offer document or attachment (max 8 MB)."
      });
    }

    const report = scanFile(buffer, filename);
    const score = report.verdict === "Dangerous" ? 90 : report.verdict === "Suspicious" ? 50 : 5;
    recordScanHistory("file", filename, report.verdict, score);

    return res.json(report);
  } catch (err) {
    console.error("File scan error:", err);
    return res.status(500).json({ error: "An error occurred while scanning the file." });
  }
});

module.exports = router;
