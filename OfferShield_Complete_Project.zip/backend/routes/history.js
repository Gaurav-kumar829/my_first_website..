/**
 * OfferShield - Scan History Route
 * Stores and retrieves historical scan records safely (JSON-backed database)
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const HISTORY_FILE = path.join(__dirname, '../data/history.json');

// Helper to read history safely
function readHistory() {
  try {
    if (!fs.existsSync(HISTORY_FILE)) {
      fs.writeFileSync(HISTORY_FILE, '[]', 'utf8');
      return [];
    }
    const data = fs.readFileSync(HISTORY_FILE, 'utf8');
    return JSON.parse(data || '[]');
  } catch (err) {
    console.error('Error reading history file:', err.message);
    return [];
  }
}

// Helper to write history safely
function writeHistory(records) {
  try {
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(records, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing history file:', err.message);
    return false;
  }
}

/**
 * GET /api/history
 * Returns the recorded scan history
 */
router.get('/', (req, res) => {
  const history = readHistory();
  return res.json({
    total: history.length,
    scans: history
  });
});

/**
 * POST /api/history
 * Manually adds a scan record (avoids storing PII)
 */
router.post('/', (req, res) => {
  const { type = 'offer', snippet = 'Offer Analysis', riskScore = 0, riskLevel = 'Low', reasonsCount = 0, verdict = 'Safe' } = req.body || {};

  const cleanRecord = {
    id: `scan-${Date.now()}`,
    date: new Date().toISOString(),
    type: String(type).slice(0, 20),
    snippet: String(snippet).slice(0, 100),
    riskScore: Number(riskScore) || 0,
    riskLevel: ['High', 'Medium', 'Low'].includes(riskLevel) ? riskLevel : 'Low',
    reasonsCount: Number(reasonsCount) || 0,
    verdict: String(verdict).slice(0, 50)
  };

  const history = readHistory();
  history.unshift(cleanRecord);

  // Keep maximum 100 recent entries
  const trimmed = history.slice(0, 100);
  writeHistory(trimmed);

  return res.status(201).json({
    message: 'Scan record stored successfully.',
    record: cleanRecord
  });
});

/**
 * DELETE /api/history
 * Clears the history database
 */
router.delete('/', (req, res) => {
  writeHistory([]);
  return res.json({ message: 'Scan history cleared successfully.' });
});

module.exports = router;
