/**
 * OfferShield - Backend Server
 * Job and Internship Offer Scam Detection Platform
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security & Middleware Configuration
app.use(cors({
  origin: '*', // Allow frontend from any local development port or file://
  methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-filename']
}));

// Support raw binary uploads specifically for scanner and deepfake endpoints
app.use('/api/scan/file', express.raw({ type: () => true, limit: '10mb' }));
app.use('/api/deepfake/image', express.raw({ type: () => true, limit: '10mb' }));

// Body parser configurations for JSON and form data
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static frontend files (works whether frontend is in ./frontend or in parent folder)
const fs = require('fs');
const frontendPath = fs.existsSync(path.join(__dirname, '../frontend/index.html'))
  ? path.join(__dirname, '../frontend')
  : path.join(__dirname, '..');
app.use(express.static(frontendPath));

// Import API routes
const analyzeRoutes = require('./routes/analyze');
const simulationRoutes = require('./routes/simulation');
const deepfakeRoutes = require('./routes/deepfake');
const scannerRoutes = require('./routes/scanner');
const historyRoutes = require('./routes/history');

// Mount API routes
app.use('/api', analyzeRoutes);
app.use('/api', simulationRoutes);
app.use('/api/deepfake', deepfakeRoutes);
app.use('/api/scan', scannerRoutes);
app.use('/api/history', historyRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'OfferShield API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Fallback to frontend index.html for root navigation
app.get('/', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// 404 Route Handler
app.use('/api/*', (req, res) => {
  res.status(404).json({ error: 'API endpoint not found.' });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err.message);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`===============================================`);
  console.log(`🛡️  OfferShield Backend Server is LIVE!`);
  console.log(`🚀 Port: ${PORT}`);
  console.log(`🌐 Web App: http://localhost:${PORT}`);
  console.log(`📡 Health Check: http://localhost:${PORT}/api/health`);
  console.log(`===============================================`);
});

module.exports = app;
